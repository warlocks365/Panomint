import{a8 as e}from"./index-CJbw1H1M.js";function r(t,n){const o=n===void 0?{type:t}:{type:t,payload:n};return e.post("/admin/agent/cmd",o).then(d=>d.data)}export{r as postAgentCmd};
